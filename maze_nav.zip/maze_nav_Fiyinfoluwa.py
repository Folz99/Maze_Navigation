import cv2
import numpy as np
import heapq
import copy


def load_and_preprocess_image(image_path):
    # Load image and convert to grayscale
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    #_, binary = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY)
    _, binary = cv2.threshold(image, 200, 255, cv2.THRESH_BINARY)
    # crop out white cells at image borders
    binary = binary[~np.all(binary == 0, axis=1)]
    binary = binary[:, ~np.all(binary == 0, axis=0)]
    return binary
    


def find_start_and_end(maze):
    # Assuming start is top-left corner and end is bottom-right
    #start = (0, 0)
    #end = (maze.shape[0] - 1, maze.shape[1] - 1)

    # Manually assign start and end points

    midpoint = int(np.rint(maze.shape[1]/2))

    start = (0, midpoint-10)
    end = (maze.shape[0] - 1, midpoint+10)
    return start, end


def neighbors(node, maze):
    x, y = node
    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nx, ny = x + dx, y + dy
        if 0 <= nx < maze.shape[0] and 0 <= ny < maze.shape[1] and maze[nx, ny] == 255:
            yield nx, ny


def heuristic(a, b):
    #return abs(a[0] - b[0]) + abs(a[1] - b[1]) # Manhattan Heuristic
    #return ((a[0] - b[0])**2 + (a[1] - b[1])**2)**(1/2) # Euclidean Heuristic
    return max(abs(a[0]-b[0]), abs(a[1]-b[1])) # Diagonal Heuristic


def a_star_search(maze, start, end):
    open_set = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, end)}

    while open_set:
        _, current = heapq.heappop(open_set)

        if current == end:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path

        for neighbor in neighbors(current, maze):
            tentative_g_score = g_score[current] + 1
            if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g_score
                f_score[neighbor] = tentative_g_score + heuristic(neighbor, end)
                if neighbor not in [i[1] for i in open_set]:
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

    return None


def draw_path(maze, path):
    colored_maze = cv2.cvtColor(maze, cv2.COLOR_GRAY2BGR)
    for x, y in path:
        colored_maze[x, y] = (0, 0, 255)
    return colored_maze


# Main function
def navigate_maze(image_path):
    maze = load_and_preprocess_image(image_path)
    #print(maze)
    start, end = find_start_and_end(maze)
    path = a_star_search(maze, start, end)

    if path:
        print("Path found!")
        solved_maze = draw_path(maze, path)
        cv2.imshow("Solved Maze", solved_maze)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        print("No path found.")


# Example usage
maze_image_path = "maze.png"  # Replace with your maze image path
navigate_maze(maze_image_path)
